<?php

/**
 * Class that structures all subsequent controllers
 * 
 */
abstract class Controller 
{

}

?>