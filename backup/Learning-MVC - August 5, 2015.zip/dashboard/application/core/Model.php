<?php

/**
 * Abstract class that structures all subsequent models
 * 
 */
abstract class Model {

	// public $model;

	// public function loadModel() {}
}

?>