<?php if (!$this) { exit(header('HTTP/1.0 403 Forbidden')); } ?>

<div class="container">
    <h2>THIS IS THE SECOND EXAMPLE - to see this required the invoking of hte method in the corresponding controller</h2>
    <p>In a real application this could be a normal page.</p>
</div>
