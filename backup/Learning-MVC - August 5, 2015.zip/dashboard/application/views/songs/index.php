<?php if (!$this) { exit(header('HTTP/1.0 403 Forbidden')); } ?>

<div class="container">
    <h1>SONG of SONGS</h1>
    <p>In a real application this could be a normal page.</p>
</div>
