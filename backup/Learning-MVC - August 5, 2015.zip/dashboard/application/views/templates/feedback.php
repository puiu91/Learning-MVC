<div class="alert alert-danger fade in">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<strong>Warning!</strong> <?php echo $errorMessage; ?>
</div>